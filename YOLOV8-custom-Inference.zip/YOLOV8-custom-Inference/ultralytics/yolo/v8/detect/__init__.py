# Ultralytics YOLO 🚀, GPL-3.0 license

from .predict import DetectionPredictor, predict
